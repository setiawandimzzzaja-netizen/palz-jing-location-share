require('dotenv').config();
const express=require('express'), helmet=require('helmet'), rateLimit=require('express-rate-limit'), path=require('path');
const app=express(), PORT=Number(process.env.PORT||3000), HOST=process.env.HOST||'0.0.0.0';
app.use(helmet({contentSecurityPolicy:false})); app.use(express.json({limit:'10kb'}));
app.use('/api/',rateLimit({windowMs:60000,limit:5})); app.use(express.static(path.join(__dirname,'public')));
app.get('/api/status',(_req,res)=>res.json({ok:true,telegramConfigured:Boolean(process.env.TELEGRAM_BOT_TOKEN&&process.env.TELEGRAM_CHAT_ID)}));
app.post('/api/location',async(req,res)=>{
 const token=process.env.TELEGRAM_BOT_TOKEN, chat=process.env.TELEGRAM_CHAT_ID;
 if(!token||!chat||token.startsWith('ISI_')||chat.startsWith('ISI_')) return res.status(503).json({error:'Bot belum dikonfigurasi.'});
 const {latitude,longitude,accuracy}=req.body||{};
 if(![latitude,longitude].every(v=>typeof v==='number'&&Number.isFinite(v))||latitude < -90||latitude>90||longitude < -180||longitude>180) return res.status(400).json({error:'Koordinat tidak valid.'});
 const map=`https://www.google.com/maps?q=${latitude},${longitude}`;
 const textMsg=`📍 PALZ JING — LOKASI DIBAGIKAN DENGAN PERSETUJUAN\nLatitude: ${latitude}\nLongitude: ${longitude}\nAkurasi perkiraan: ${Math.round(Number(accuracy)||0)} meter\nPeta: ${map}\n\nLokasi dikirim setelah pengguna menekan tombol dan menyetujui izin browser.`;
 try { const r=await fetch(`https://api.telegram.org/bot${token}/sendMessage`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({chat_id:chat,text:textMsg,disable_web_page_preview:true})}); const d=await r.json(); if(!r.ok||!d.ok) return res.status(502).json({error:'Telegram gagal mengirim. Periksa token dan chat ID.'}); res.json({ok:true,message:'Lokasi berhasil dikirim ke Telegram.'}); }
 catch(e){console.error(e.message);res.status(502).json({error:'Tidak dapat menghubungi Telegram.'});}
});
app.listen(PORT,HOST,()=>console.log(`PALZ JING aktif pada port ${PORT}`));
