PALZ JING LOCATION SHARE — SIAP DEPLOY
Paket ini aplikasi Node.js nyata. Link publik belum bisa dibuat tanpa akun hosting milikmu.

DEPLOY RENDER:
1. Buat akun Render dan GitHub.
2. Buat repository GitHub (private disarankan), lalu upload isi folder ini.
3. Jangan upload file .env.
4. Di Render pilih New > Blueprint, hubungkan repository.
5. Render membaca render.yaml dan membuat layanan web.
6. Isi Environment: TELEGRAM_BOT_TOKEN dan TELEGRAM_CHAT_ID.
7. Deploy. Setelah status Live, Render memberi URL HTTPS *.onrender.com.
8. Buka URL dari perangkat kedua, tekan tombol dan setujui izin lokasi.

CATATAN:
- Pengguna harus menekan tombol dan menyetujui izin browser. Tidak ada pelacakan diam-diam.
- Token disimpan sebagai Environment Variable di hosting, jangan masukkan ke file frontend atau bagikan.
- HTTPS diperlukan untuk lokasi browser di link publik.
- Paket gratis dapat tidur saat tidak digunakan.
- Bot harus sudah di-/start oleh akun penerima; chat ID harus benar.
